# CSS Grid Tutorial

A Pen created on CodePen.io. Original URL: [https://codepen.io/WebDevSimplified/pen/qJgJGX](https://codepen.io/WebDevSimplified/pen/qJgJGX).

